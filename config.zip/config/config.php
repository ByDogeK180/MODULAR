<?php
// Entorno: local | produccion
define('APP_ENV', 'produccion');

// SMTP Hostinger
define('MAIL_HOST', 'smtp.hostinger.com');
define('MAIL_USER', 'notificaciones@schoolcare.site');
define('MAIL_PASS', 'Proyecmodular8@');
define('MAIL_PORT', 465);
define('MAIL_SECURE', 'ssl');

// URL base
if (APP_ENV === 'local') {
    define('BASE_URL', 'http://localhost/dashboard/Modular');
} else {
    define('BASE_URL', 'https://schoolcare.site');
}
